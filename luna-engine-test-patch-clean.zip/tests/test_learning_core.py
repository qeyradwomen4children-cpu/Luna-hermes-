import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

ENGINE_PATH = Path(__file__).resolve().parents[1] / "luna_capability_gap_engine_fixed-1.py"
SPEC = importlib.util.spec_from_file_location("luna_capability_gap_engine", ENGINE_PATH)
ENGINE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
sys.modules[SPEC.name] = ENGINE
SPEC.loader.exec_module(ENGINE)
Evaluation, Gap, Improvement, LunaLearningCore = (
    ENGINE.Evaluation, ENGINE.Gap, ENGINE.Improvement, ENGINE.LunaLearningCore
)


class LunaLearningCoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.core = LunaLearningCore(self.root)

    def test_evaluation_and_summary_persist(self):
        record_id = self.core.evaluate(Evaluation("research", 0.8, "three reproducible checks"))
        self.assertTrue(record_id)
        self.assertEqual(self.core.summary()["evaluations"], 1)
        self.assertEqual(LunaLearningCore(self.root).summary()["mean_score"], 0.8)

    def test_gap_requires_target_above_baseline(self):
        with self.assertRaises(ValueError):
            self.core.open_gap(Gap("coding", 0.7, 0.6, ["weak tests"], 0.5))
        self.assertTrue(self.core.open_gap(Gap("coding", 0.4, 0.8, ["missing regression tests"], 0.7)))
        self.assertEqual(self.core.summary()["open_gaps"], 1)

    def test_invalid_scores_are_rejected(self):
        for score in (-0.1, 1.1, float("nan"), float("inf")):
            with self.subTest(score=score), self.assertRaises(ValueError):
                self.core.evaluate(Evaluation("reasoning", score, "test evidence"))

    def test_retention_requires_reproducible_measured_gain(self):
        with self.assertRaises(ValueError):
            self.core.record_improvement(Improvement("reasoning", "new checklist", 0.5, 0.7,
                "one run", retained=True, reproducible=False, test_method="repeat benchmark"))
        self.assertEqual(self.core.summary()["retained_principles"], 0)

    def test_reproducible_gain_can_be_retained_and_traced(self):
        experiment_id = self.core.record_improvement(Improvement("research", "verify primary sources",
            0.5, 0.8, "same benchmark on three runs", retained=True, reproducible=True,
            test_method="three-run fixed benchmark", limitations="small sample"))
        data = json.loads(self.core.principles.read_text(encoding="utf-8"))
        self.assertEqual(data["research"]["experiment_id"], experiment_id)
        self.assertEqual(self.core.summary()["reproducible_gains"], 1)
        self.assertEqual(self.core.summary()["retained_principles"], 1)

    def test_corrupt_log_fails_closed(self):
        self.core.eval_log.write_text("{not-json}\n", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "Corrupt JSON"):
            self.core.summary()


if __name__ == "__main__":
    unittest.main()
